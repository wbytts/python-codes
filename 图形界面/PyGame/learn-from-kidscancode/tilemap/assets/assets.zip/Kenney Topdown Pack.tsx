<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="kenney topdown pack" tilewidth="64" tileheight="64" spacing="10" tilecount="540" columns="27">
 <image source="img/spritesheet_tiles.png" width="1988" height="1470"/>
</tileset>
